import Logo from "../assets/logo.png"
import LogoFoot from "../assets/logo-foot.png"

export const Images = {
    Logo, LogoFoot
}